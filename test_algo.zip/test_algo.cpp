﻿// test_algo.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>


#include "cse_geoarithmetic.h"

int main()
{
    CSE_GeoArithmetic GeoArithmetic;
    double dLon1 = 120;
    double dLat1 = 50;
    double dAzimuth1 = 55.5999;
    double dDistance = 300127;
    double dSemiMajorAxis = WGS84_SEMIMAJORAXIS;
    double dSemiMinorAxis = WGS84_SEMIMINORAXIS;
    
    double dLon2 = 0;       // 终点经度
    double dLat2 = 0;       // 终点纬度
    GeoArithmetic.CalPointByDistanceAndAzimuth(dSemiMajorAxis,
        dSemiMinorAxis,
        dLat1,
        dLon1,
        dAzimuth1,
        dDistance,
        &dLat2,
        &dLon2);
    
    printf("lon2 = %.6f\tlat2 = %.6f\n", dLon2, dLat2);

    dDistance = 0;
    dAzimuth1 = 0;
    double dAzimuth2 = 0;

    GeoArithmetic.CalDistanceAndAzimuthByTwoPoints(dSemiMajorAxis,
        dSemiMinorAxis,
        dLat1,
        dLon1,
        dLat2,
        dLon2,
        &dDistance,
        &dAzimuth1,
        &dAzimuth2);

    printf("dDistance = %.6f米，dAzimuth1 = %.6f度，dAzimuth2 = %.6f度",dDistance,dAzimuth1,dAzimuth2);

}

